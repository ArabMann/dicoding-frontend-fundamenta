import 'regenerator-runtime';
import './script/components/navbar.js'
import './script/components/card.js'
import main from "./script/view/main.js";

document.addEventListener('DOMContentLoaded', main);